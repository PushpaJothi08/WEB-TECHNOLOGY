const mongoose = require('mongoose');

const entrySchema = new mongoose.Schema({
  date: String,
  temperature: Number,
  mood: String,
  location: String,
  humidity: Number,
  wind: Number,
  condition: String
});

module.exports = mongoose.model('Entry', entrySchema);
