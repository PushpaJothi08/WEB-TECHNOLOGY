// --- Weather Journal App Frontend ---
// Author: ChatGPT Custom Version
// Updated: Adds humidity, wind, and weather condition emojis

const apiKey = "617fc6c87352c7b66c64175877d13a6e"; // ✅ Your OpenWeatherMap key
const baseUrl = "https://api.openweathermap.org/data/2.5/weather";

let currentTemp = null;
let currentLocation = null;
let currentHumidity = null;
let currentWind = null;
let currentCondition = null;

// 🔹 Map weather description to emoji + label
function getWeatherEmoji(desc) {
  desc = desc.toLowerCase();
  if (desc.includes("rain")) return "🌧️ Rainy";
  if (desc.includes("cloud")) return "☁️ Cloudy";
  if (desc.includes("clear")) return "☀️ Sunny";
  if (desc.includes("snow")) return "❄️ Snowy";
  if (desc.includes("wind")) return "💨 Windy";
  if (desc.includes("storm") || desc.includes("thunder")) return "⛈️ Stormy";
  return "🌍 Moderate Weather";
}

// 🔹 Get Weather by current location (geolocation)
async function getWeatherByLocation() {
  if (!navigator.geolocation) {
    alert("Geolocation is not supported by your browser!");
    return;
  }

  navigator.geolocation.getCurrentPosition(async position => {
    const lat = position.coords.latitude;
    const lon = position.coords.longitude;

    const res = await fetch(`${baseUrl}?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`);
    const data = await res.json();

    if (data.cod !== 200) {
      alert("Unable to get weather for your location!");
      return;
    }

    updateWeatherDisplay(data);
  });
}

// 🔹 Get Weather by city name
async function getWeatherByCity() {
  const city = document.getElementById("cityInput").value.trim();
  if (!city) {
    alert("Please enter a city name!");
    return;
  }

  const res = await fetch(`${baseUrl}?q=${city}&appid=${apiKey}&units=metric`);
  const data = await res.json();

  if (data.cod !== 200) {
    alert("City not found!");
    return;
  }

  updateWeatherDisplay(data);
}

// 🔹 Update displayed weather info
function updateWeatherDisplay(data) {
  currentTemp = data.main.temp;
  currentLocation = data.name;
  currentHumidity = data.main.humidity;
  currentWind = data.wind.speed;
  const desc = data.weather[0].description;
  currentCondition = getWeatherEmoji(desc);

  document.getElementById("weatherInfo").innerHTML = `
    <b>${currentCondition}</b> in <b>${data.name}</b>: ${currentTemp}°C, ${desc}<br>
    💧 Humidity: ${currentHumidity}% &nbsp;&nbsp; 🌬️ Wind: ${currentWind} m/s
  `;
}

// 🔹 Save entry to MongoDB
async function saveEntry() {
  const mood = document.getElementById("mood").value.trim();
  if (!currentTemp || !mood || !currentLocation) {
    alert("Please get weather and enter your mood!");
    return;
  }

  const entry = {
    date: new Date().toLocaleString(),
    temperature: currentTemp,
    mood,
    location: currentLocation,
    humidity: currentHumidity,
    wind: currentWind,
    condition: currentCondition
  };

  await fetch("/add", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(entry)
  });

  document.getElementById("mood").value = "";
  getEntries();
}

// 🔹 Fetch saved entries from MongoDB
async function getEntries() {
  const res = await fetch("/all");
  const data = await res.json();
  const log = document.getElementById("log");
  log.innerHTML = "";

  data.reverse().forEach(e => {
    const div = document.createElement("div");
    div.className = "card my-2 p-3";
    div.innerHTML = `
      <h5>${e.location} — ${e.date}</h5>
      <p><b>${e.condition || "🌍 Moderate Weather"}</b></p>
      <p><b>Temperature:</b> ${e.temperature}°C</p>
      <p><b>Humidity:</b> ${e.humidity || "-"}%</p>
      <p><b>Wind:</b> ${e.wind || "-"} m/s</p>
      <p><b>Mood:</b> ${e.mood}</p>
    `;
    log.appendChild(div);
  });
}

// Load previous logs on page load
window.onload = getEntries;